require('dotenv').config();
global.sessionid = process.env.SESSION_ID || '';
global.BOT_PREFIX = '.';
global.owners = ['254740007567@s.whatsapp.net']; // Your number in correct format
